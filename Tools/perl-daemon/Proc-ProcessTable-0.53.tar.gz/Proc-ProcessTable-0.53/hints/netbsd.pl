symlink "os/NetBSD.c", "OS.c" || die "Could not link os/NetBSD.c to os/OS.c\n";
