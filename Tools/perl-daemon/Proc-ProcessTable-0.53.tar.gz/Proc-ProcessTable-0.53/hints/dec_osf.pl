symlink "os/DecOSF.c", "OS.c" || die "Could not link os/DecOSF.c to OS.c\n";
